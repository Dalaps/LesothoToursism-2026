document.addEventListener("DOMContentLoaded", () => {
  // Keep the footer year current on every page.
  document.querySelectorAll(".year").forEach((node) => {
    node.textContent = new Date().getFullYear();
  });

  // Accessible gallery preview with next/previous controls (Bootstrap modal).
  const galleryButtons = [...document.querySelectorAll("[data-gallery-index]")];
  const modalElement = document.getElementById("galleryModal");
  if (galleryButtons.length && modalElement && window.bootstrap) {
    const galleryItems = galleryButtons.map((button) => {
      const image = button.querySelector("img");
      return { src: image.src, alt: image.alt, title: button.querySelector("span")?.textContent || image.alt };
    });
    const modal = bootstrap.Modal.getOrCreateInstance(modalElement);
    const modalImage = document.getElementById("modalImage");
    const modalTitle = document.getElementById("galleryModalLabel");
    const counter = document.getElementById("galleryCounter");
    let currentIndex = 0;

    function showImage(index) {
      currentIndex = (index + galleryItems.length) % galleryItems.length;
      const item = galleryItems[currentIndex];
      modalImage.src = item.src;
      modalImage.alt = item.alt;
      modalTitle.textContent = item.title;
      counter.textContent = `${currentIndex + 1} of ${galleryItems.length}`;
    }
    galleryButtons.forEach((button) => button.addEventListener("click", () => {
      showImage(Number(button.dataset.galleryIndex));
      modal.show();
    }));
    document.getElementById("prevImage")?.addEventListener("click", () => showImage(currentIndex - 1));
    document.getElementById("nextImage")?.addEventListener("click", () => showImage(currentIndex + 1));
    document.addEventListener("keydown", (event) => {
      if (!modalElement.classList.contains("show")) return;
      if (event.key === "ArrowLeft") showImage(currentIndex - 1);
      if (event.key === "ArrowRight") showImage(currentIndex + 1);
    });
  }

  // Registration form: HTML5 checks plus custom confirm-password validation.
  const form = document.getElementById("registrationForm");
  if (form) {
    const password = document.getElementById("password");
    const confirmPassword = document.getElementById("confirmPassword");
    const alertBox = document.getElementById("formAlert");

    function checkPasswords() {
      const matches = password.value === confirmPassword.value && confirmPassword.value.length > 0;
      confirmPassword.setCustomValidity(matches ? "" : "Passwords must match.");
      return matches;
    }
    password.addEventListener("input", checkPasswords);
    confirmPassword.addEventListener("input", checkPasswords);

    form.addEventListener("submit", (event) => {
      event.preventDefault();
      checkPasswords();
      form.classList.add("was-validated");
      if (!form.checkValidity()) {
        alertBox.className = "alert alert-danger";
        alertBox.textContent = "Please correct the highlighted fields before continuing.";
        const firstInvalid = form.querySelector(":invalid");
        firstInvalid?.focus();
        return;
      }
      alertBox.className = "alert alert-success";
      alertBox.textContent = `Thank you, ${document.getElementById("fullName").value.trim()}! Your demonstration form passed validation. No information has been sent or saved.`;
      alertBox.scrollIntoView({ behavior: "smooth", block: "nearest" });
    });

    form.addEventListener("reset", () => {
      window.setTimeout(() => {
        form.classList.remove("was-validated");
        alertBox.className = "alert d-none";
        alertBox.textContent = "";
        confirmPassword.setCustomValidity("");
      }, 0);
    });
  }
});